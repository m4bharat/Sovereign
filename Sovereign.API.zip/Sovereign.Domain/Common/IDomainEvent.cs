
namespace Sovereign.Domain.Common;

public interface IDomainEvent
{
    DateTime OccurredOnUtc { get; }
}
